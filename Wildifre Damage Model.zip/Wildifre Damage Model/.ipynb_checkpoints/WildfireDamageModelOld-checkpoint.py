### imports ###
import geopandas as gpd
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import numpy as np
import os
import pandas as pd
import sys
import warnings
warnings.simplefilter(action='ignore', category=pd.errors.PerformanceWarning)

class WildfireModel:
    def __init__(self, year_of_interest):
        ### save year of interest ###
        self.year_of_interest = year_of_interest
        
        ### get working directory ###
        self.CWD = os.getcwd()

        ### data set bounds ###
        self.DATASET_START_YEAR = 2010
        self.DATASET_END_YEAR   = 2021
        
        if year_of_interest < self.DATASET_START_YEAR or year_of_interest > self.DATASET_END_YEAR:
            print(f"Currently raw data only supports model years from {self.DATASET_START_YEAR} (inclusive) to {self.DATASET_END_YEAR} (inclusive)")
            sys.exit("Exiting program")
        ### counties raw data ###
        self.ALL_COUNTIES = pd.read_csv(self.CWD + "/CA_Counties.csv")

        ### BENMAP raw data ###
        self.AGES           = ["0_17", "18_24", "25_34", "45_54", "55_64", "65_74", "75_84", "85+"]
        self.CONDITIONS     = ["All Respiratory HA", "All Cardiovascular HA", "Mortality Non-Accidental"]
        BASELINE_RATES      = pd.read_csv(self.CWD + "/Baseline_Rates.csv")                              # people / 100 people / yr, from BenMAP Table D-2 and D-5
        self.BASELINE_RATES = BASELINE_RATES.set_index("Condition") / 365                                # convert to people / 100 ppl / day
        self.HEALTH_COSTS   = pd.read_csv(self.CWD + "/Health_Costs.csv").set_index("Condition")         # $ / instance, from BenMAP Table H-2 and H-3
        self.BETA_VALUES    = pd.read_csv(self.CWD + "/Beta_Values.csv").set_index("Condition")          # unitless, all for log-linear form, table E-3 and G-1
        self.FIRE_SMOKE_ADJ = pd.read_csv(self.CWD + "/FireSmokeAdj_Values.csv").set_index("Condition")  # unitless from delfino paper Table 4
        
        self.THIS_YEAR_POPULATION_DATA              = self.prep_population_data(year_of_interest)
        self.PM_RAW_DATA, self.COUNTIES, self.DATES = self.prep_PM_data(year_of_interest)

    ### prep population raw data ###
    def prep_population_data(self, year_of_interest):
        ### population raw data ###
        ALL_POPULATION_DATA = pd.read_csv(self.CWD + "/Population.csv")

        pop_index1 = list(ALL_POPULATION_DATA.loc[:, "Name"])
        pop_index2 = []
        for elem in pop_index1:
            elem = elem[:elem.index(" County, CA")]
            pop_index2.append(elem)

        age_categories =["# Age | Under 5 years, "  ,
                         "# Age | 5 to 9 years, "   ,
                         "# Age | 10 to 14 years, " ,
                         "# Age | 15 to 17 years, " ,
                         "# Age | 18 and 19 years, ",
                         "# Age | 20 to 24 years, " ,
                         "# Age | 25 to 34 years, " ,
                         "# Age | 35 to 44 years, " ,
                         "# Age | 45 to 54 years, " ,
                         "# Age | 55 to 64 years, " ,
                         "# Age | 65 to 74 years, " ,
                         "# Age | 75 to 84 years, " ,
                         "# Age | 85 years and over, "]

        THIS_YEAR_POPULATION_DATA = pd.DataFrame(index = ALL_POPULATION_DATA.index)
        for age_category in age_categories:
            THIS_YEAR_POPULATION_DATA = pd.concat([THIS_YEAR_POPULATION_DATA, ALL_POPULATION_DATA.loc[:, age_category + str(year_of_interest)]], axis = 1)

        THIS_YEAR_POPULATION_DATA["# Total Population, " + str(year_of_interest)] = THIS_YEAR_POPULATION_DATA.iloc[:, :].sum(axis=1)
        THIS_YEAR_POPULATION_DATA["# Age | Under 17 years, " + str(year_of_interest)] = THIS_YEAR_POPULATION_DATA.iloc[:, 0:4].sum(axis=1)
        THIS_YEAR_POPULATION_DATA["# Age | 18 to 24 years, " + str(year_of_interest)] = THIS_YEAR_POPULATION_DATA.iloc[:, 4:6].sum(axis=1)
        THIS_YEAR_POPULATION_DATA = THIS_YEAR_POPULATION_DATA.drop(columns = ["# Age | Under 5 years, "   + str(year_of_interest),
                                                                              "# Age | 5 to 9 years, "    + str(year_of_interest),
                                                                              "# Age | 10 to 14 years, "  + str(year_of_interest),
                                                                              "# Age | 15 to 17 years, "  + str(year_of_interest),
                                                                              "# Age | 18 and 19 years, " + str(year_of_interest),
                                                                              "# Age | 20 to 24 years, "  + str(year_of_interest)])
        THIS_YEAR_POPULATION_DATA["Counties"] = pd.Series((elem for elem in pop_index2))
        THIS_YEAR_POPULATION_DATA = THIS_YEAR_POPULATION_DATA.set_index("Counties")

        rename_dict = {"# Age | 25 to 34 years, "    + str(year_of_interest)   : "25_34",
                       "# Age | 35 to 44 years, "    + str(year_of_interest)   : "35_44",
                       "# Age | 45 to 54 years, "    + str(year_of_interest)   : "45_54",
                       "# Age | 55 to 64 years, "    + str(year_of_interest)   : "55_64",
                       "# Age | 65 to 74 years, "    + str(year_of_interest)   : "65_74",
                       "# Age | 75 to 84 years, "    + str(year_of_interest)   : "75_84",
                       "# Age | 85 years and over, " + str(year_of_interest)   : "85+"  ,
                       "# Total Population, "        + str(year_of_interest)   : "Total",
                       "# Age | Under 17 years, "    + str(year_of_interest)   : "0_17" ,
                       "# Age | 18 to 24 years, "    + str(year_of_interest)   : "18_24"}
        # Population data for year of interest
        # Row is counties, column is age group
        THIS_YEAR_POPULATION_DATA = THIS_YEAR_POPULATION_DATA.rename(columns=rename_dict)
        return THIS_YEAR_POPULATION_DATA

    ### PM2.5 raw data ###
    def prep_PM_data(self, year_of_interest):
        # file path
        path = self.CWD + "/" + "PM2.5_CA_" + str(self.DATASET_START_YEAR) + "_" + str(self.DATASET_END_YEAR)
        # populate dfs from raw data
        key                = "PM2.5_CA_" + str(year_of_interest) + ".csv"
        PM_raw_data        = pd.read_csv(path + "/" + key).set_index("Date")
        PM_raw_data["key"] = PM_raw_data.index + "_" + PM_raw_data.COUNTY
        COUNTIES = PM_raw_data.COUNTY.unique()
        DATES    = PM_raw_data.index.unique().sort_values()
        return PM_raw_data, COUNTIES, DATES

    ### find average PM from all sensors ###
    def find_average_df(self):
        # find average PM2.5 and AQI values for each county
        PM_data = pd.DataFrame(index = self.DATES, columns = self.COUNTIES)
        number_of_sensors = {}

        for date in self.DATES:
            for county in self.COUNTIES:
                this_key = date + "_" + county
                pm_inter = self.PM_RAW_DATA[self.PM_RAW_DATA.key == this_key].loc[:, "Daily Mean PM2.5 Concentration"]
                # find number of sensors
                if county not in number_of_sensors:
                    number_of_sensors[county] = len(pm_inter.index)
                number_of_sensors[county] = max(number_of_sensors[county], len(pm_inter.index))
                PM_data.loc[date, county]  = pm_inter.mean()
        return PM_data, number_of_sensors

    ### print info about counties and sensors ###
    def print_county_info(self, PM_data, number_of_sensors):
        # find and print all counties not contained in data set
        for row_num in range(len(self.ALL_COUNTIES.index)):
            if np.array(self.ALL_COUNTIES.iloc[row_num]) not in np.array(self.COUNTIES):
                print(np.array(self.ALL_COUNTIES.iloc[row_num][0]), "County is not contained in data set")
        print()
        # find and print number of sensors for each county
        for county in self.COUNTIES:
            print(county, "County has", number_of_sensors[county], "sensors")
        print()
        # find and print number of NA values for each county
        for county in self.COUNTIES:
            number_of_na_days = PM_data.loc[:, county].isna().sum()
            print(county, "County has", number_of_na_days, "days of bad data")
        
    ### algorithm for finding a fire day ###
    def find_fire_days(self, acceptable_single_day_change_p, minimum_for_fire_day, fire_day_end_cut_off_p, PM_data):
        for county in self.COUNTIES:
            PM_data[county + "_single_day_change"] = 0
        for county in self.COUNTIES:
            PM_data[county + "_fire_day"] = False
        for county in self.COUNTIES:
            # calculate single day change in PM
            for row_num in range(len(self.DATES) - 1):
                row_num = row_num + 1
                try:
                    PM_data.loc[self.DATES[row_num], county + "_single_day_change"] = \
                    PM_data.loc[self.DATES[row_num], county] - PM_data.loc[self.DATES[row_num - 1], county]
                except:
                    PM_data.loc[self.DATES[row_num], county + "_single_day_change"] = np.nan
            # cut off variables
            acceptable_single_day_change = PM_data.loc[:, county + "_single_day_change"].quantile(acceptable_single_day_change_p)
            fire_day_end_cut_off         = PM_data.loc[:, county].quantile(fire_day_end_cut_off_p)
            # first run through, fire days on large single day changes
            for row_num in range(len(self.DATES) - 1):
                row_num = row_num + 1
                if (PM_data.loc[self.DATES[row_num], county + "_single_day_change"] > acceptable_single_day_change) and\
                (PM_data.loc[self.DATES[row_num], county] > minimum_for_fire_day):
                    PM_data.loc[self.DATES[row_num], county + "_fire_day"] = True
            # second run through, fire days only stop when we cross over the county cut off
            for row_num in range(len(self.DATES) - 1):
                row_num = row_num + 1
                if (PM_data.loc[self.DATES[row_num - 1], county + "_fire_day"] == True) and\
                (PM_data.loc[self.DATES[row_num], county] > fire_day_end_cut_off):
                    PM_data.loc[self.DATES[row_num], county + "_fire_day"] = True
        return PM_data

    ### calculate respiratory damages ###
    def find_fire_damages(self, PM_data_fire_days):
        baseline_damages = pd.DataFrame(index = self.DATES)
        damages = pd.DataFrame(index = self.DATES)
        for condition in self.CONDITIONS:
            for county in self.COUNTIES:
                baseline_damages.loc[:, f"nonfire_{condition}_instances_{county}"]   = 0
                damages.loc[:, f"nonfire_{condition}_instances_{county}"]            = 0
            for county in self.COUNTIES:
                baseline_damages.loc[:, f"nonfire_{condition}_damages_{county}"]     = 0
                damages.loc[:, f"nonfire_{condition}_damages_{county}"]              = 0
            for county in self.COUNTIES:
                damages.loc[:, f"fire_{condition}_instances_{county}"]               = 0
            for county in self.COUNTIES:
                damages.loc[:, f"fire_{condition}_damages_{county}"]                 = 0

        for county in self.COUNTIES:
            median_PM = PM_data_fire_days.loc[:, county].median(axis = 0)
            for condition in self.CONDITIONS:
                for age in self.AGES:
                    pop           = self.THIS_YEAR_POPULATION_DATA.loc[county, age] / 100
                    health_cost   = self.HEALTH_COSTS.loc[condition, age]
                    baseline_rate = self.BASELINE_RATES.loc[condition, age]
                    beta_value    = self.BETA_VALUES.loc[condition, age]
                    fs_adj        = self.FIRE_SMOKE_ADJ.loc[condition, age]
                    baseline_damages.loc[:, f"nonfire_{condition}_instances_{county}"] += baseline_rate * pop
                    baseline_damages.loc[:, f"nonfire_{condition}_damages_{county}"]   += baseline_rate * pop * health_cost
                    for date in self.DATES:
                        delta_pm        = PM_data_fire_days.loc[date, county] - median_PM
                        if delta_pm < 0:
                            delta_pm = 0
                        change          = baseline_rate * (1 - (1 / np.exp(beta_value * delta_pm)))
                        nonfire_rate    = baseline_rate + change
                        fire_rate       = nonfire_rate * fs_adj
                        if PM_data_fire_days.loc[date, county + "_fire_day"]:
                            damages.loc[date, f"fire_{condition}_instances_{county}"]    += (fire_rate - baseline_rate)* pop
                            damages.loc[date, f"fire_{condition}_damages_{county}"]      += (fire_rate - baseline_rate)* pop * health_cost
                        else:
                            damages.loc[date, f"nonfire_{condition}_instances_{county}"] += (nonfire_rate - baseline_rate) * pop
                            damages.loc[date, f"nonfire_{condition}_damages_{county}"]   += (nonfire_rate - baseline_rate) * pop * health_cost
        return baseline_damages, damages

    ### summarize damages ###
    def summarize_damages(self, area_of_interest, start_date, end_date, baseline_damages, damages, summary_level = "Grand Total", per_capita = False):
        if per_capita:
            instance_unit = "Instances/100,000 People"
            dollar_unit   = "$/Person"
        else:
            instance_unit = "Instances"
            dollar_unit = "$M"
            
        if area_of_interest[0] == "CA":
            county_list = self.COUNTIES
        else:
            for this_county in area_of_interest:
                if this_county not in self.COUNTIES:
                    print(f"{this_county} is not avaliable in raw data set")
                    sys.exit("Exiting program")   
            county_list = area_of_interest
            
                
        baseline_instances_subcats = []
        baseline_instances_final_names = {}
        instances_subcats = []
        instances_final_names = {}
        for condition in self.CONDITIONS:
            # baseline
            baseline_instances_subcats.append(f"nonfire_{condition}_instances")
            baseline_instances_final_names[f"nonfire_{condition}_instances"] = f"{instance_unit} of {condition}"
            # PM
            instances_subcats.append(f"nonfire_{condition}_instances")
            instances_final_names[f"nonfire_{condition}_instances"] = f"Additional {instance_unit} of {condition} During Non Fire Days due to High PM"
        for condition in self.CONDITIONS:
            # PM
            instances_subcats.append(f"fire_{condition}_instances")
            instances_final_names[f"fire_{condition}_instances"] = f"Additional {instance_unit} of {condition} During Fire Days due to High PM"
        baseline_damages_subcats = []
        baseline_damages_final_names = {}
        damages_subcats = []
        damages_final_names = {}
        for condition in self.CONDITIONS:
            # baseline
            baseline_damages_subcats.append(f"nonfire_{condition}_damages")
            baseline_damages_final_names[f"nonfire_{condition}_damages"] = f"Damages ({dollar_unit}) due to {condition}"
            # PM
            damages_subcats.append(f"nonfire_{condition}_damages")
            damages_final_names[f"nonfire_{condition}_damages"] = f"Additional Damages ({dollar_unit}) due to {condition} During Non Fire Days due to High PM"
        for condition in self.CONDITIONS:
            # PM
            damages_subcats.append(f"fire_{condition}_damages")
            damages_final_names[f"fire_{condition}_damages"] = f"Additional Damages ({dollar_unit}) due to {condition} During Fire Days due to High PM"
        if summary_level == "Grand Total":
            # Baseline
            baseline_instances_results = pd.DataFrame(0, index = baseline_instances_subcats, columns = [f"{instance_unit}"])
            baseline_damage_results    = pd.DataFrame(0, index = baseline_damages_subcats, columns = [f"Damages {dollar_unit}"])
            # PM
            instances_results          = pd.DataFrame(0, index = instances_subcats, columns = [f"{instance_unit}"])
            damage_results             = pd.DataFrame(0, index = damages_subcats, columns = [f"Damages {dollar_unit}"])
            # Baseline
            # instances
            for baseline_instances_subcat in baseline_instances_subcats:
                if per_capita:
                    for county in county_list:
                        baseline_instances_results.loc[baseline_instances_subcat, f"{instance_unit}"] += \
                        baseline_damages.loc[start_date: end_date, baseline_instances_subcat + "_" + county].sum()
                    baseline_instances_results.loc[baseline_instances_subcat, f"{instance_unit}"] = \
                    100000 * baseline_instances_results.loc[baseline_instances_subcat, f"{instance_unit}"] / self.THIS_YEAR_POPULATION_DATA.loc[:, "Total"].sum()
                else:
                    for county in county_list:
                        baseline_instances_results.loc[baseline_instances_subcat, f"{instance_unit}"] += \
                        baseline_damages.loc[start_date: end_date, baseline_instances_subcat + "_" + county].sum()
            # damages
            for baseline_damages_subcat in baseline_damages_subcats:
                if per_capita:
                    for county in county_list:
                        baseline_damage_results.loc[baseline_damages_subcat, f"Damages {dollar_unit}"] += \
                        baseline_damages.loc[start_date: end_date, baseline_damages_subcat + "_" + county].sum()
                    baseline_damage_results.loc[baseline_damages_subcat, f"Damages {dollar_unit}"] = \
                    baseline_damage_results.loc[baseline_damages_subcat, f"Damages {dollar_unit}"] / self.THIS_YEAR_POPULATION_DATA.loc[:, "Total"].sum()
                else:
                    for county in county_list:
                        baseline_damage_results.loc[baseline_damages_subcat, f"Damages {dollar_unit}"] += \
                        baseline_damages.loc[start_date: end_date, baseline_damages_subcat + "_" + county].sum() / 1000000
            baseline_instances_results = baseline_instances_results.rename(axis = 0, mapper = baseline_instances_final_names)
            baseline_damage_results = baseline_damage_results.rename(axis = 0,mapper = baseline_damages_final_names)
            baseline_damage_results.loc["Total Baseline Damages", :] = baseline_damage_results.iloc[:, :].sum()
            
            # PM
            # instances
            for instances_subcat in instances_subcats:
                if per_capita:
                    for county in county_list:
                        instances_results.loc[instances_subcat, f"{instance_unit}"] += \
                        damages.loc[start_date: end_date, instances_subcat + "_" + county].sum()
                    instances_results.loc[instances_subcat, f"{instance_unit}"] = \
                    100000 * instances_results.loc[instances_subcat, f"{instance_unit}"] / self.THIS_YEAR_POPULATION_DATA.loc[:, "Total"].sum()
                else:
                    for county in county_list:
                        instances_results.loc[instances_subcat, f"{instance_unit}"] += damages.loc[start_date: end_date, instances_subcat + "_" + county].sum()
            # damages
            for damages_subcat in damages_subcats:
                if per_capita:
                    for county in county_list:
                        damage_results.loc[damages_subcat, f"Damages {dollar_unit}"] += \
                        damages.loc[start_date: end_date, damages_subcat + "_" + county].sum()
                    damage_results.loc[damages_subcat, f"Damages {dollar_unit}"] = \
                    damage_results.loc[damages_subcat, f"Damages {dollar_unit}"] / self.THIS_YEAR_POPULATION_DATA.loc[:, "Total"].sum()
                else:
                    for county in county_list:
                        damage_results.loc[damages_subcat, f"Damages {dollar_unit}"] += \
                        damages.loc[start_date: end_date, damages_subcat + "_" + county].sum() / 1000000
            instances_results = instances_results.rename(axis = 0, mapper = instances_final_names)
            damage_results    = damage_results.rename(axis = 0,mapper = damages_final_names)
            damage_results.loc["Total Non Fire Damages", :] = damage_results.iloc[0:3, :].sum()
            damage_results.loc["Total Fire Damages", :]     = damage_results.iloc[3:6, :].sum()
        # By county
        else:
            # Baseline
            baseline_instances_results = pd.DataFrame(index = county_list, columns = baseline_instances_subcats)
            baseline_damage_results = pd.DataFrame(index = county_list, columns = baseline_damages_subcats)
            # instances
            for baseline_instances_subcat in baseline_instances_subcats:
                if per_capita:
                    for county in county_list:
                        baseline_instances_results.loc[county, baseline_instances_subcat] = \
                        100000 * baseline_damages.loc[start_date: end_date, baseline_instances_subcat + "_" + county].sum() / self.THIS_YEAR_POPULATION_DATA.loc[county, "Total"]
                else:
                    for county in county_list:
                        baseline_instances_results.loc[county, baseline_instances_subcat] = \
                        baseline_damages.loc[start_date: end_date, baseline_instances_subcat + "_" + county].sum()
            # damages
            for baseline_damages_subcat in baseline_damages_subcats:
                if per_capita:
                    for county in county_list:
                        baseline_damage_results.loc[county, baseline_damages_subcat] = \
                        baseline_damages.loc[start_date: end_date, baseline_damages_subcat + "_" + county].sum()/ self.THIS_YEAR_POPULATION_DATA.loc[county, "Total"]
                else:
                    for county in county_list:
                        baseline_damage_results.loc[county, baseline_damages_subcat] = \
                        baseline_damages.loc[start_date: end_date, baseline_damages_subcat + "_" + county].sum() / 1000000
            baseline_instances_results = baseline_instances_results.rename(columns = baseline_instances_final_names)
            baseline_damage_results = baseline_damage_results.rename(columns = baseline_damages_final_names)
            baseline_damage_results.loc[:, "Total Baseline Damages"] = baseline_damage_results.iloc[:, :].sum(axis = 1)
            # PM
            instances_results = pd.DataFrame(index = county_list, columns = instances_subcats)
            damage_results = pd.DataFrame(index = county_list, columns = damages_subcats)
            # instances
            for instances_subcat in instances_subcats:
                if per_capita:
                    for county in county_list:
                        instances_results.loc[county, instances_subcat] = \
                        100000 * damages.loc[start_date: end_date, instances_subcat + "_" + county].sum() / self.THIS_YEAR_POPULATION_DATA.loc[county, "Total"]
                else:
                    for county in county_list:
                        instances_results.loc[county, instances_subcat] = damages.loc[start_date: end_date, instances_subcat + "_" + county].sum()
            # damages
            for damages_subcat in damages_subcats:
                if per_capita:
                    for county in county_list:
                        damage_results.loc[county, damages_subcat] = \
                        damages.loc[start_date: end_date, damages_subcat + "_" + county].sum() / self.THIS_YEAR_POPULATION_DATA.loc[county, "Total"]
                else:
                    for county in county_list:
                        damage_results.loc[county, damages_subcat] = damages.loc[start_date: end_date, damages_subcat + "_" + county].sum() / 1000000
            instances_results = instances_results.rename(columns = instances_final_names)
            damage_results    = damage_results.rename(columns = damages_final_names)
            damage_results.loc[:, "Total Non Fire Damages"] = damage_results.iloc[:, 0:3].sum(axis = 1)
            damage_results.loc[:, "Total Fire Damages"]     = damage_results.iloc[:, 3:6].sum(axis = 1)
            
        pd.options.display.float_format = '{:,.2f}'.format
        return baseline_instances_results, baseline_damage_results, instances_results, damage_results

    ### plot fire days  ###
    def plot_fire_days(self, county_list, PM_data_fire_days):
        for county in county_list:
            if county not in self.COUNTIES:
                print(f"{county} is not avaliable in raw data set")
                sys.exit("Exiting program")   
            x = np.arange(0, 365, 50)
            plot_fire_days = PM_data_fire_days.loc[:, county][PM_data_fire_days.loc[:, county + "_fire_day"]]
            fig, ax = plt.subplots()
            ax.plot(PM_data_fire_days.loc[:, county])
            plt.xticks(ticks=x, labels=[str(el) for el in x], fontsize=10)
            ax.scatter(plot_fire_days.index, plot_fire_days, color = "r")
            ax.set_title("Fire Days for " + county + " County in " + str(self.year_of_interest))
            ax.set_ylabel("PM (micro g / m3)")
            ax.set_xlabel("Day of the Year")
            plt.axhline(y=PM_data_fire_days.loc[:, county].median(), color='r', linestyle='-')
            #plt.savefig(str(self.year_of_interest) + "_" + county,  transparent=True)
        
    ### plot fire days  ###
    def make_map(self, results_series, Name):
        GEO_RAW_DATA = gpd.read_file("CA_Counties_mapping").set_index("NAME")
        geo_plot     = gpd.GeoDataFrame(pd.concat([GEO_RAW_DATA.loc[:, "geometry"], results_series], axis = 1).rename(columns = {results_series.name:Name}))
        plt.rcParams['figure.figsize'] = [10,10]
        fig, ax      = plt.subplots(1, 1)
        geo_plot.plot(column = Name, ax=ax, legend=True, cmap="Reds", figsize=(2, 2))
        plt.title(str(self.year_of_interest) + " " + Name)
        #plt.savefig(str(self.year_of_interest) + " " + Name,  transparent=True)